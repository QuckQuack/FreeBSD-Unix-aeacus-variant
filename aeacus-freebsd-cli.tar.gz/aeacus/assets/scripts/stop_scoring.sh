#!/bin/sh
# Stops scoring for this image, deletes the scoring engine, and powers off.
# Run through the "stopscoring" command (which adds sudo when needed).

# The aeacus directory is two levels above this script (<dir>/assets/scripts).
dir=$(cd "$(dirname "$0")/../.." && pwd)

printf 'Would you like to stop scoring for this image? [y/N] '
read -r answer
case $answer in
[yY] | [yY][eE][sS]) ;;
*)
	echo "Confirmation failed! Scoring was not stopped."
	exit 1
	;;
esac

echo "Stopping scoring, and shutting down."
if ! /usr/sbin/service aeacus stop && /usr/sbin/service aeacus onestatus >/dev/null 2>&1; then
	echo "Unable to stop the aeacus service." >&2
	exit 1
fi
/bin/rm -f "$dir/phocus" "$dir/scoring.dat"
/sbin/shutdown -p now
